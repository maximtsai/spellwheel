function sdkShowRewardAd(onStart, onFinish, onError) {

}

function sdkShowMidgameAd(onStart, onFinish, onError) {

}

function sdkShowHappyTime() {

}

function sdkShowBannerAd() {

}

function sdkGameStart() {

}

function sdkGameEnd() {

}


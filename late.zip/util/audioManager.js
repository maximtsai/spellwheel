// audiomanager
let soundList = [];
globalVolume = 0.9;
globalMusicVol = 0.9;
globalMusic = null;
globalTempMusic = null;

function initializeSounds(scene) {
    // for (let i in audioFiles) {
    //     let audioData = audioFiles[i];
    //     if (soundList[audioData.name]) {
    //         console.warn('audio name duplicate ', audioData.name);
    //     }
    //     soundList[audioData.name] = scene.sound.add(audioData.name);
    // }
    globalVolume = localStorage.getItem("globalVolume") || 0.9;
    globalMusicVol = localStorage.getItem("globalMusicVol") || 0.9;
}

function playSound(name, volume = 1, loop = false, isMusic = false) {
    if (!soundList[name]) {
        soundList[name] = PhaserScene.sound.add(name);
    }
    soundList[name].fullVolume = volume;
    soundList[name].volume = soundList[name].fullVolume * globalVolume;
    soundList[name].loop = loop;
    soundList[name].isMusic = isMusic;
    if (soundList[name].currTween) {
        soundList[name].currTween.stop();
        soundList[name].currTween = null;
    }
    if (isMusic) {
        soundList[name].volume = volume * globalMusicVol;
        globalMusic = soundList[name];
    }
    soundList[name].detune = 0;
    soundList[name].play();
    return soundList[name];
}

function playMusic(name, volume = 1, loop = false) {
    return this.playSound(name, volume, loop, true);
}

function playFakeBGMusic(name) {
    if (!soundList[name]) {
        soundList[name] = PhaserScene.sound.add(name);
    }
    globalTempMusic = soundList[name];
    if (soundList[name].currTween) {
        soundList[name].currTween.stop();
        soundList[name].currTween = null;
    }
    soundList[name].volume = globalMusicVol;
    soundList[name].play();
}

function updateGlobalVolume(newVol = 1) {
    globalVolume = newVol;
    localStorage.setItem("globalVolume", newVol.toString());
    for (let i in soundList) {
        if (soundList[i].isPlaying) {
            if (soundList[i] !== globalMusic) {
                soundList[i].volume = soundList[i].fullVolume * globalVolume;
            }
        }
    }
}

function updateGlobalMusicVolume(newVol = 1) {
    globalMusicVol = newVol;
    localStorage.setItem("globalMusicVol", newVol.toString());
    if (globalMusic) {
        globalMusic.volume = globalMusic.fullVolume * newVol;
    }
    if (globalTempMusic) {
        globalTempMusic.volume = newVol;
    }
}

function setVolume(sound, volume = 0, duration) {
    let globalToUse = sound.isMusic ? globalMusicVol : globalVolume;
    sound.fullVolume = volume;
    if (!duration) {
        sound.volume = sound.fullVolume * globalToUse;
    } else {
        PhaserScene.tweens.add({
            targets: sound,
            volume: sound.fullVolume * globalToUse,
            duration: duration
        });
    }
}


function fadeAwaySound(sound, duration = 650, ease, onComplete) {
    sound.fullVolume = 0
    sound.currTween = PhaserScene.tweens.add({
        targets: sound,
        volume: sound.fullVolume,
        ease: ease,
        duration: duration,
        onComplete: () => {
            sound.stop();
            if (onComplete) {
                onComplete();
            }
        }
    });
}

function fadeInSound(sound, volume = 1, duration = 1000) {
    let globalToUse = sound.isMusic ? globalMusicVol : globalVolume;
    sound.fullVolume = volume
    PhaserScene.tweens.add({
        targets: sound,
        volume: sound.fullVolume * globalToUse,
        duration: duration,
        ease: 'Quad.easeIn'
    });
}

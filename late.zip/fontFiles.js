const fontFiles = [
    { name: 'damage', url: 'fonts/damage.xml', imageUrl: 'fonts/damage.png' },
    { name: 'heal', url: 'fonts/heal.xml', imageUrl: 'fonts/heal.png' },
    { name: 'armor', url: 'fonts/armor.xml', imageUrl: 'fonts/armor.png' },
    { name: 'block', url: 'fonts/block.xml', imageUrl: 'fonts/block.png' },
    { name: 'void', url: 'fonts/void.xml', imageUrl: 'fonts/void.png' },
    { name: 'bonus', url: 'fonts/bonus.xml', imageUrl: 'fonts/bonus.png' },
    { name: 'normal', url: 'fonts/normal.xml', imageUrl: 'fonts/normal.png' },
    { name: 'normalStroke', url: 'fonts/normalStroke.xml', imageUrl: 'fonts/normalStroke.png' },
    { name: 'plainBold', url: 'fonts/plain_bold.xml', imageUrl: 'fonts/plain_bold.png' },
];
